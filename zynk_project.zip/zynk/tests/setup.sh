#!/bin/bash

# Setup script for running integration tests

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed. Please install Python 3."
    exit 1
fi

# Install required packages
echo "Installing required Python packages..."
pip3 install requests python-dotenv

# Create .env file from example if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file from example..."
    cp .env.example .env
    echo "Please edit the .env file with your actual configuration before running tests."
fi

echo "Setup complete. Run tests with: python3 integration_test.py"
