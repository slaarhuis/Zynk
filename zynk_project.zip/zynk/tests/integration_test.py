import requests
import json
import time
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configuration
ADMIN_API_URL = os.getenv('ADMIN_API_URL', 'http://localhost:4000/api')
CONTENT_CONNECTOR_URL = os.getenv('CONTENT_CONNECTOR_URL', 'http://localhost:5000/api')
API_KEY = os.getenv('API_KEY', 'test_api_key')
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', 'admin@example.com')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'password123')

# Test results tracking
tests_passed = 0
tests_failed = 0

def print_test_result(test_name, passed, message=None):
    global tests_passed, tests_failed
    
    if passed:
        tests_passed += 1
        result = "✅ PASSED"
    else:
        tests_failed += 1
        result = "❌ FAILED"
    
    print(f"{result} - {test_name}")
    if message:
        print(f"       {message}")
    print()

def test_admin_api_health():
    try:
        response = requests.get(f"{ADMIN_API_URL.rstrip('/')}/health")
        
        if response.status_code == 200 and response.json().get('status') == 'ok':
            print_test_result("Admin API Health Check", True)
            return True
        else:
            print_test_result("Admin API Health Check", False, 
                             f"Expected status 'ok', got: {response.text}")
            return False
    except Exception as e:
        print_test_result("Admin API Health Check", False, str(e))
        return False

def test_content_connector_health():
    try:
        response = requests.get(f"{CONTENT_CONNECTOR_URL.rstrip('/')}/health")
        
        if response.status_code == 200 and response.json().get('status') == 'ok':
            print_test_result("Content Connector Health Check", True)
            return True
        else:
            print_test_result("Content Connector Health Check", False, 
                             f"Expected status 'ok', got: {response.text}")
            return False
    except Exception as e:
        print_test_result("Content Connector Health Check", False, str(e))
        return False

def test_content_connector_manifest():
    try:
        base_url = CONTENT_CONNECTOR_URL.rstrip('/').replace('/api', '')
        response = requests.get(f"{base_url}/manifest.json")
        
        if response.status_code == 200 and 'endpoints' in response.json():
            print_test_result("Content Connector Manifest", True)
            return True
        else:
            print_test_result("Content Connector Manifest", False, 
                             f"Expected manifest with endpoints, got: {response.text}")
            return False
    except Exception as e:
        print_test_result("Content Connector Manifest", False, str(e))
        return False

def test_admin_authentication():
    try:
        # Login to admin interface
        response = requests.post(
            f"{ADMIN_API_URL}/auth/login",
            json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}
        )
        
        if response.status_code == 200 and 'token' in response.json():
            token = response.json()['token']
            print_test_result("Admin Authentication", True)
            return token
        else:
            print_test_result("Admin Authentication", False, 
                             f"Failed to authenticate: {response.text}")
            return None
    except Exception as e:
        print_test_result("Admin Authentication", False, str(e))
        return None

def test_create_template(token):
    if not token:
        print_test_result("Create Template", False, "No authentication token available")
        return None
    
    try:
        # Create a test template
        template_data = {
            "spaceId": "test-space",
            "assetId": "test-asset",
            "name": "Test Template",
            "description": "Template for testing",
            "documentType": "document",
            "fields": [
                {
                    "name": "customerName",
                    "type": "string",
                    "required": True,
                    "description": "Customer name"
                },
                {
                    "name": "amount",
                    "type": "number",
                    "required": True,
                    "description": "Amount in USD"
                }
            ]
        }
        
        response = requests.post(
            f"{ADMIN_API_URL}/templates",
            json=template_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code in [200, 201] and 'template' in response.json():
            template_id = response.json()['template']['_id']
            print_test_result("Create Template", True)
            return template_id
        else:
            print_test_result("Create Template", False, 
                             f"Failed to create template: {response.text}")
            return None
    except Exception as e:
        print_test_result("Create Template", False, str(e))
        return None

def test_create_item(token, template_id):
    if not token or not template_id:
        print_test_result("Create Item", False, "Missing token or template_id")
        return None
    
    try:
        # Get template details
        template_response = requests.get(
            f"{ADMIN_API_URL}/templates/{template_id}",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if template_response.status_code != 200:
            print_test_result("Create Item", False, 
                             f"Failed to get template details: {template_response.text}")
            return None
        
        template = template_response.json()['template']
        
        # Create a test item
        item_data = {
            "name": "Test Item",
            "description": "Item for testing",
            "templateInfo": {
                "spaceId": template['spaceId'],
                "assetId": template['assetId'],
                "documentType": template['documentType']
            },
            "payload": {
                "email": "user@example.com",
                "data": {
                    "customerName": "Test Customer",
                    "amount": 1000
                },
                "includePdf": True
            }
        }
        
        response = requests.post(
            f"{ADMIN_API_URL}/items",
            json=item_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code in [200, 201] and 'item' in response.json():
            item_id = response.json()['item']['_id']
            print_test_result("Create Item", True)
            return item_id
        else:
            print_test_result("Create Item", False, 
                             f"Failed to create item: {response.text}")
            return None
    except Exception as e:
        print_test_result("Create Item", False, str(e))
        return None

def test_sync_data(token):
    if not token:
        print_test_result("Sync Data", False, "No authentication token available")
        return False
    
    try:
        # Trigger sync all
        response = requests.post(
            f"{ADMIN_API_URL}/sync/all",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code == 200:
            print_test_result("Sync Data", True)
            return True
        else:
            print_test_result("Sync Data", False, 
                             f"Failed to sync data: {response.text}")
            return False
    except Exception as e:
        print_test_result("Sync Data", False, str(e))
        return False

def test_content_connector_list():
    try:
        # Wait a moment for sync to complete
        time.sleep(2)
        
        # List content from connector
        response = requests.get(f"{CONTENT_CONNECTOR_URL}/content")
        
        if response.status_code == 200 and 'content' in response.json():
            content_items = response.json()['content']
            if len(content_items) > 0:
                print_test_result("Content Connector List", True)
                return content_items[0]['id'] if content_items else None
            else:
                print_test_result("Content Connector List", False, 
                                 "Content list is empty, sync may have failed")
                return None
        else:
            print_test_result("Content Connector List", False, 
                             f"Failed to list content: {response.text}")
            return None
    except Exception as e:
        print_test_result("Content Connector List", False, str(e))
        return None

def test_content_connector_get_item(item_id):
    if not item_id:
        print_test_result("Content Connector Get Item", False, "No item ID available")
        return False
    
    try:
        # Get item details from connector
        response = requests.get(f"{CONTENT_CONNECTOR_URL}/content/{item_id}")
        
        if response.status_code == 200 and 'id' in response.json():
            print_test_result("Content Connector Get Item", True)
            return True
        else:
            print_test_result("Content Connector Get Item", False, 
                             f"Failed to get item: {response.text}")
            return False
    except Exception as e:
        print_test_result("Content Connector Get Item", False, str(e))
        return False

def test_content_connector_generate(item_id):
    if not item_id:
        print_test_result("Content Connector Generate", False, "No item ID available")
        return False
    
    try:
        # Generate document from item
        response = requests.post(f"{CONTENT_CONNECTOR_URL}/content/{item_id}/generate")
        
        if response.status_code in [200, 202]:
            print_test_result("Content Connector Generate", True)
            return True
        else:
            print_test_result("Content Connector Generate", False, 
                             f"Failed to generate document: {response.text}")
            return False
    except Exception as e:
        print_test_result("Content Connector Generate", False, str(e))
        return False

def run_all_tests():
    print("🧪 Starting Zynk Integration Tests\n")
    
    # Health checks
    admin_health = test_admin_api_health()
    connector_health = test_content_connector_health()
    manifest = test_content_connector_manifest()
    
    if not admin_health or not connector_health:
        print("\n❌ Critical services are not available. Aborting tests.")
        return
    
    # Admin interface tests
    token = test_admin_authentication()
    template_id = test_create_template(token)
    item_id = test_create_item(token, template_id)
    
    # Integration tests
    sync_success = test_sync_data(token)
    
    # Content connector tests
    content_item_id = test_content_connector_list()
    if content_item_id:
        test_content_connector_get_item(content_item_id)
        test_content_connector_generate(content_item_id)
    
    # Print summary
    print("\n📊 Test Summary:")
    print(f"Total tests: {tests_passed + tests_failed}")
    print(f"Passed: {tests_passed}")
    print(f"Failed: {tests_failed}")
    
    if tests_failed == 0:
        print("\n✅ All tests passed! The Zynk project is working correctly.")
    else:
        print(f"\n❌ {tests_failed} tests failed. Please check the logs above for details.")

if __name__ == "__main__":
    run_all_tests()
