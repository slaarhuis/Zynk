# Zynk Project Documentation

## Overview
Zynk is a service that enables end-users to create non-editable, personalized fact sheets as PDFs through Templafy. The system consists of two main components:

1. **Custom Content Connector for Templafy**: Implements Templafy's Custom Content Connector API to expose content items to Templafy users.
2. **Admin Interface**: Allows administrators to create and manage items with payloads for Templafy's DocGen API.

## System Architecture

### Components
- **Admin Interface Backend**: Node.js/TypeScript API with Express
- **Admin Interface Frontend**: Next.js application with Tailwind CSS
- **Custom Content Connector**: Node.js/TypeScript API implementing Templafy's connector specification
- **MongoDB Database**: Shared database for both components

### Integration
The components are integrated through a synchronization mechanism:
- Admin Interface creates and manages items and templates
- Content Connector exposes these items to Templafy
- Synchronization ensures data consistency between components

## Features

### Admin Interface
- User authentication and authorization
- Template management
- Item creation and editing
- DocGen API payload configuration
- Manual synchronization to Content Connector

### Custom Content Connector
- Implements Templafy's Custom Content Connector API
- Provides content listing with search and pagination
- Supports document generation through Templafy
- Exposes a manifest endpoint for Templafy integration

## Deployment

The project is configured for deployment on a Synology NAS using Docker:
- Docker Compose orchestration
- Persistent volume storage
- Secure communication between components
- Environment-based configuration

See the [Deployment Guide](/home/ubuntu/zynk/docker/DEPLOYMENT_GUIDE.md) for detailed instructions.

## Testing

Integration tests are provided to verify the functionality of the entire system:
- Health checks for all components
- Authentication testing
- Template and item creation
- Synchronization verification
- Content Connector functionality

## Getting Started

1. Follow the [Deployment Guide](/home/ubuntu/zynk/docker/DEPLOYMENT_GUIDE.md) to set up the system
2. Create an admin user account
3. Add templates based on your Word templates
4. Create items with appropriate DocGen payloads
5. Synchronize data to the Content Connector
6. Configure Templafy to use the Custom Content Connector

## Maintenance

Regular maintenance tasks include:
- Database backups
- Monitoring logs
- Updating the application when new versions are available
- Synchronizing data after significant changes

## Troubleshooting

Common issues and their solutions are documented in the [Deployment Guide](/home/ubuntu/zynk/docker/DEPLOYMENT_GUIDE.md).

For additional support, please refer to the documentation or contact the development team.
