import { Request, Response } from 'express';
import Item from '../models/Item';

/**
 * Implements the Templafy Custom Content Connector API
 * Based on: https://github.com/templafy/CustomContentConnector
 */

// Get all content items
export const getContent = async (req: Request, res: Response) => {
  try {
    // Parse query parameters
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const skip = (page - 1) * limit;
    const search = req.query.search as string;
    
    // Build query
    let query: any = {};
    
    // Add search if provided
    if (search) {
      query = { $text: { $search: search } };
    }
    
    // Execute query with pagination
    const items = await Item.find(query)
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // Get total count for pagination
    const total = await Item.countDocuments(query);
    
    // Format response according to Templafy's requirements
    const response = {
      content: items.map(item => ({
        id: item._id.toString(),
        name: item.name,
        description: item.description || '',
        type: item.templateInfo.documentType,
        created: item.createdAt.toISOString(),
        modified: item.updatedAt.toISOString(),
        // Add custom properties that might be useful for filtering
        properties: {
          templateId: `${item.templateInfo.spaceId}/${item.templateInfo.assetId}`,
          documentType: item.templateInfo.documentType
        }
      })),
      pagination: {
        page,
        pageSize: limit,
        totalItems: total,
        totalPages: Math.ceil(total / limit)
      }
    };
    
    res.status(200).json(response);
  } catch (error) {
    console.error('Get content error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get content item by ID
export const getContentById = async (req: Request, res: Response) => {
  try {
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({ message: 'Content not found' });
    }
    
    // Format response according to Templafy's requirements
    const response = {
      id: item._id.toString(),
      name: item.name,
      description: item.description || '',
      type: item.templateInfo.documentType,
      created: item.createdAt.toISOString(),
      modified: item.updatedAt.toISOString(),
      // Add custom properties that might be useful for filtering
      properties: {
        templateId: `${item.templateInfo.spaceId}/${item.templateInfo.assetId}`,
        documentType: item.templateInfo.documentType
      },
      // Include template info for document generation
      templateInfo: item.templateInfo,
      // Include payload for document generation
      payload: item.payload
    };
    
    res.status(200).json(response);
  } catch (error) {
    console.error('Get content by ID error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get content metadata (available properties for filtering)
export const getContentMetadata = async (req: Request, res: Response) => {
  try {
    // Return metadata about available properties for filtering
    const response = {
      properties: [
        {
          id: "documentType",
          name: "Document Type",
          type: "string",
          values: ["document", "presentation", "spreadsheet", "text-element"],
          multiSelect: false
        }
      ]
    };
    
    res.status(200).json(response);
  } catch (error) {
    console.error('Get content metadata error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Generate document from content item
export const generateDocument = async (req: Request, res: Response) => {
  try {
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({ message: 'Content not found' });
    }
    
    // In a real implementation, this would call Templafy's DocGen API
    // For now, we'll just return a success message with the payload that would be sent
    
    const response = {
      message: 'Document generation request received',
      status: 'pending',
      contentId: item._id.toString(),
      templateInfo: item.templateInfo,
      payload: item.payload
    };
    
    res.status(202).json(response);
  } catch (error) {
    console.error('Generate document error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
