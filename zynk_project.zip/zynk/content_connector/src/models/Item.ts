import mongoose, { Document, Schema } from 'mongoose';

export interface IItem extends Document {
  name: string;
  description: string;
  templateInfo: {
    spaceId: string;
    assetId: string;
    documentType: string;
  };
  payload: any;
  createdBy: mongoose.Types.ObjectId;
  updatedBy: mongoose.Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

const ItemSchema: Schema = new Schema({
  name: { 
    type: String, 
    required: true,
    trim: true
  },
  description: { 
    type: String, 
    required: false 
  },
  templateInfo: {
    spaceId: { 
      type: String, 
      required: true 
    },
    assetId: { 
      type: String, 
      required: true 
    },
    documentType: { 
      type: String, 
      required: true,
      enum: ['document', 'presentation', 'spreadsheet', 'text-element']
    }
  },
  payload: { 
    type: Schema.Types.Mixed, 
    required: true 
  },
  createdBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  updatedBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Add text index for search functionality
ItemSchema.index({ name: 'text', description: 'text' });

export default mongoose.model<IItem>('Item', ItemSchema);
