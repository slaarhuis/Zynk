import axios from 'axios';
import { Request, Response } from 'express';
import Item from '../models/Item';
import Template from '../models/Template';

/**
 * Service to interact with the Admin Interface API
 */
export class AdminApiService {
  private baseUrl: string;
  private apiKey: string;

  constructor() {
    this.baseUrl = process.env.ADMIN_API_URL || 'http://localhost:4000/api';
    this.apiKey = process.env.ADMIN_API_KEY || '';
  }

  /**
   * Sync items from the Admin Interface
   */
  async syncItems(): Promise<{ success: boolean; count: number; message?: string }> {
    try {
      // Get items from Admin API
      const response = await axios.get(`${this.baseUrl}/items`, {
        headers: {
          'Authorization': `ApiKey ${this.apiKey}`
        }
      });

      const items = response.data.items;
      let syncCount = 0;

      // Upsert each item
      for (const item of items) {
        await Item.findOneAndUpdate(
          { _id: item._id },
          item,
          { upsert: true, new: true }
        );
        syncCount++;
      }

      return {
        success: true,
        count: syncCount
      };
    } catch (error: any) {
      console.error('Sync items error:', error);
      return {
        success: false,
        count: 0,
        message: error.message || 'Failed to sync items from Admin API'
      };
    }
  }

  /**
   * Sync templates from the Admin Interface
   */
  async syncTemplates(): Promise<{ success: boolean; count: number; message?: string }> {
    try {
      // Get templates from Admin API
      const response = await axios.get(`${this.baseUrl}/templates`, {
        headers: {
          'Authorization': `ApiKey ${this.apiKey}`
        }
      });

      const templates = response.data.templates;
      let syncCount = 0;

      // Upsert each template
      for (const template of templates) {
        await Template.findOneAndUpdate(
          { _id: template._id },
          template,
          { upsert: true, new: true }
        );
        syncCount++;
      }

      return {
        success: true,
        count: syncCount
      };
    } catch (error: any) {
      console.error('Sync templates error:', error);
      return {
        success: false,
        count: 0,
        message: error.message || 'Failed to sync templates from Admin API'
      };
    }
  }

  /**
   * Generate document using Admin API
   */
  async generateDocument(itemId: string): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/items/${itemId}/test`,
        {},
        {
          headers: {
            'Authorization': `ApiKey ${this.apiKey}`
          }
        }
      );

      return {
        success: true,
        result: response.data.result
      };
    } catch (error: any) {
      console.error('Generate document error:', error);
      return {
        success: false,
        message: error.message || 'Failed to generate document'
      };
    }
  }
}

// Controller for sync operations
export const syncController = {
  syncItems: async (req: Request, res: Response) => {
    try {
      const adminApiService = new AdminApiService();
      const result = await adminApiService.syncItems();
      
      if (result.success) {
        res.status(200).json({
          message: `Successfully synced ${result.count} items`,
          count: result.count
        });
      } else {
        res.status(500).json({
          message: result.message || 'Sync failed'
        });
      }
    } catch (error) {
      console.error('Sync items controller error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  
  syncTemplates: async (req: Request, res: Response) => {
    try {
      const adminApiService = new AdminApiService();
      const result = await adminApiService.syncTemplates();
      
      if (result.success) {
        res.status(200).json({
          message: `Successfully synced ${result.count} templates`,
          count: result.count
        });
      } else {
        res.status(500).json({
          message: result.message || 'Sync failed'
        });
      }
    } catch (error) {
      console.error('Sync templates controller error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  
  syncAll: async (req: Request, res: Response) => {
    try {
      const adminApiService = new AdminApiService();
      const templatesResult = await adminApiService.syncTemplates();
      const itemsResult = await adminApiService.syncItems();
      
      if (templatesResult.success && itemsResult.success) {
        res.status(200).json({
          message: `Successfully synced ${templatesResult.count} templates and ${itemsResult.count} items`,
          templates: templatesResult.count,
          items: itemsResult.count
        });
      } else {
        res.status(500).json({
          message: 'Sync partially failed',
          templatesSuccess: templatesResult.success,
          itemsSuccess: itemsResult.success,
          templatesMessage: templatesResult.message,
          itemsMessage: itemsResult.message
        });
      }
    } catch (error) {
      console.error('Sync all controller error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

export default AdminApiService;
