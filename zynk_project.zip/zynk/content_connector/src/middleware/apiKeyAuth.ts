import { Request, Response, NextFunction } from 'express';

// API key authentication middleware
export const apiKeyAuth = (req: Request, res: Response, next: NextFunction) => {
  try {
    const apiKey = process.env.ADMIN_API_KEY;
    
    if (!apiKey) {
      console.warn('API key not configured in environment variables');
      return res.status(500).json({ message: 'API key not configured' });
    }
    
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('ApiKey ')) {
      return res.status(401).json({ message: 'API key required' });
    }
    
    const providedKey = authHeader.split(' ')[1];
    
    if (providedKey !== apiKey) {
      return res.status(401).json({ message: 'Invalid API key' });
    }
    
    next();
  } catch (error) {
    console.error('API key auth error:', error);
    return res.status(500).json({ message: 'Authentication error' });
  }
};
