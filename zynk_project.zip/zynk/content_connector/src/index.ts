import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';

// Import routes
import contentRoutes from './routes/contentRoutes';
import syncRoutes from './routes/syncRoutes';

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/zynk';
mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  });

// Routes
app.use('/api/content', contentRoutes);
app.use('/api/sync', syncRoutes);

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// Templafy connector manifest
app.get('/manifest.json', (req, res) => {
  const baseUrl = `${req.protocol}://${req.get('host')}`;
  
  const manifest = {
    name: "Zynk Content Connector",
    description: "Custom content connector for Templafy to generate personalized fact sheets",
    version: "1.0.0",
    apiVersion: "1.0",
    endpoints: {
      content: `${baseUrl}/api/content`,
      metadata: `${baseUrl}/api/content/metadata`
    },
    capabilities: {
      search: true,
      filter: true,
      pagination: true,
      generate: true
    }
  };
  
  res.status(200).json(manifest);
});

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);
  res.status(500).json({
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Content Connector running on port ${PORT}`);
});

export default app;
