import { Router } from 'express';
import { 
  getContent, 
  getContentById, 
  getContentMetadata,
  generateDocument
} from '../controllers/contentController';

const router = Router();

// Content endpoints following Templafy Custom Content Connector API specification
router.get('/', getContent);
router.get('/metadata', getContentMetadata);
router.get('/:id', getContentById);
router.post('/:id/generate', generateDocument);

export default router;
