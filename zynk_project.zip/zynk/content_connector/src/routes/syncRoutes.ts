import { Router } from 'express';
import { syncController } from '../services/adminApiService';
import { apiKeyAuth } from '../middleware/apiKeyAuth';

const router = Router();

// Apply API key authentication to all sync routes
router.use(apiKeyAuth);

// Sync endpoints
router.post('/items', syncController.syncItems);
router.post('/templates', syncController.syncTemplates);
router.post('/all', syncController.syncAll);

export default router;
