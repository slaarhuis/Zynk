import axios from 'axios';

// Define API base URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

// Configure axios defaults
axios.defaults.baseURL = API_URL;

// Add request interceptor to include token
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Define API service interfaces
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  refreshToken: string;
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
  };
}

export interface Item {
  _id: string;
  name: string;
  description: string;
  templateInfo: {
    spaceId: string;
    assetId: string;
    documentType: string;
  };
  payload: any;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Template {
  _id: string;
  spaceId: string;
  assetId: string;
  name: string;
  description: string;
  documentType: string;
  fields: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface Asset {
  _id: string;
  name: string;
  description: string;
  mimeType: string;
  tags: string;
  filePath: string;
  previewUrl: string;
  altText?: string;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  search?: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    pages: number;
  };
}

// Auth API
export const authApi = {
  login: (credentials: LoginCredentials) => 
    axios.post<AuthResponse>('/auth/login', credentials),
  
  refreshToken: (refreshToken: string) => 
    axios.post<{ token: string }>('/auth/refresh-token', { refreshToken }),
  
  getProfile: () => 
    axios.get('/auth/profile')
};

// Items API
export const itemsApi = {
  getItems: (params?: PaginationParams) => 
    axios.get<PaginatedResponse<Item>>('/items', { params }),
  
  getItem: (id: string) => 
    axios.get<{ item: Item }>(`/items/${id}`),
  
  createItem: (item: Omit<Item, '_id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>) => 
    axios.post<{ message: string, item: Item }>('/items', item),
  
  updateItem: (id: string, item: Partial<Omit<Item, '_id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>) => 
    axios.put<{ message: string, item: Item }>(`/items/${id}`, item),
  
  deleteItem: (id: string) => 
    axios.delete<{ message: string }>(`/items/${id}`),
  
  testItem: (id: string) => 
    axios.post<{ message: string, result: any }>(`/items/${id}/test`)
};

// Templates API
export const templatesApi = {
  getTemplates: (params?: PaginationParams) => 
    axios.get<PaginatedResponse<Template>>('/templates', { params }),
  
  getTemplate: (id: string) => 
    axios.get<{ template: Template }>(`/templates/${id}`),
  
  createTemplate: (template: Omit<Template, '_id' | 'createdAt' | 'updatedAt'>) => 
    axios.post<{ message: string, template: Template }>('/templates', template),
  
  updateTemplate: (id: string, template: Partial<Omit<Template, '_id' | 'createdAt' | 'updatedAt'>>) => 
    axios.put<{ message: string, template: Template }>(`/templates/${id}`, template),
  
  deleteTemplate: (id: string) => 
    axios.delete<{ message: string }>(`/templates/${id}`),
  
  syncTemplates: () => 
    axios.post<{ message: string, count: number }>('/templates/sync')
};

// Assets API
export const assetsApi = {
  getAssets: (params?: PaginationParams) => 
    axios.get<PaginatedResponse<Asset>>('/assets', { params }),
  
  getAsset: (id: string) => 
    axios.get<{ asset: Asset }>(`/assets/${id}`),
  
  createAsset: (formData: FormData) => 
    axios.post<{ message: string, asset: Asset }>('/assets', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }),
  
  updateAsset: (id: string, formData: FormData) => 
    axios.put<{ message: string, asset: Asset }>(`/assets/${id}`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }),
  
  deleteAsset: (id: string) => 
    axios.delete<{ message: string }>(`/assets/${id}`)
};

export default {
  auth: authApi,
  items: itemsApi,
  templates: templatesApi,
  assets: assetsApi
};
