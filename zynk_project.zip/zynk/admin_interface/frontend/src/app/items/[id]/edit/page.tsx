import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import AppLayout from '../../../components/AppLayout';
import { itemsApi, templatesApi, Item, Template } from '../../../api/api';

// Define validation schema
const itemSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().min(1, 'Description is required'),
  payload: z.record(z.any()).optional(),
});

type ItemFormData = z.infer<typeof itemSchema>;

export default function EditItemPage() {
  const params = useParams();
  const router = useRouter();
  const [item, setItem] = useState<Item | null>(null);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const itemId = params.id as string;
  
  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    setValue,
    watch,
    reset
  } = useForm<ItemFormData>({
    resolver: zodResolver(itemSchema)
  });
  
  // Fetch item and templates
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch item
        const itemResponse = await itemsApi.getItem(itemId);
        setItem(itemResponse.data.item);
        
        // Fetch templates
        const templatesResponse = await templatesApi.getTemplates();
        setTemplates(templatesResponse.data.templates);
        
        // Find selected template
        const template = templatesResponse.data.templates.find(
          t => t.spaceId === itemResponse.data.item.templateInfo.spaceId && 
               t.assetId === itemResponse.data.item.templateInfo.assetId
        ) || null;
        
        setSelectedTemplate(template);
        
        // Set form values
        reset({
          name: itemResponse.data.item.name,
          description: itemResponse.data.item.description,
          payload: itemResponse.data.item.payload
        });
        
      } catch (err: any) {
        console.error('Error fetching data:', err);
        setError('Failed to load item data. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    if (itemId) {
      fetchData();
    }
  }, [itemId, reset]);
  
  const onSubmit = async (data: ItemFormData) => {
    if (!item) {
      setError('Item not found');
      return;
    }
    
    try {
      setSaving(true);
      setError(null);
      
      const response = await itemsApi.updateItem(itemId, {
        name: data.name,
        description: data.description,
        payload: data.payload
      });
      
      // Redirect to item detail page
      router.push(`/items/${itemId}`);
    } catch (err: any) {
      console.error('Error updating item:', err);
      setError(err.response?.data?.message || 'Failed to update item. Please try again.');
    } finally {
      setSaving(false);
    }
  };
  
  const handlePayloadChange = (field: string, value: any) => {
    const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
    const newData = { ...currentPayload.data, [field]: value };
    setValue('payload', { ...currentPayload, data: newData });
  };
  
  if (loading) {
    return (
      <AppLayout>
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500">Loading...</p>
        </div>
      </AppLayout>
    );
  }
  
  if (error && !item) {
    return (
      <AppLayout>
        <div className="bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Edit Item</h1>
          <button
            onClick={() => router.push(`/items/${itemId}`)}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            Cancel
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Item Details</h2>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  id="name"
                  className={`mt-1 block w-full border ${errors.name ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  {...register('name')}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                <textarea
                  id="description"
                  rows={3}
                  className={`mt-1 block w-full border ${errors.description ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  {...register('description')}
                />
                {errors.description && (
                  <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Template</label>
                <div className="mt-1 bg-gray-100 p-3 rounded-md">
                  <p className="text-sm text-gray-900">
                    {selectedTemplate?.name || 'Unknown Template'} ({item?.templateInfo.documentType})
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Template cannot be changed. Create a new item to use a different template.
                  </p>
                </div>
              </div>
              
              {selectedTemplate && (
                <>
                  <div className="border-t pt-4">
                    <h3 className="text-lg font-medium text-gray-900">Template Data</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Edit the data that will be used to generate the document.
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                      defaultValue={item?.payload.email || ''}
                      onChange={(e) => {
                        const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
                        setValue('payload', { ...currentPayload, email: e.target.value });
                      }}
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Email address to identify user in Templafy.
                    </p>
                  </div>
                  
                  {selectedTemplate.fields.map((field) => (
                    <div key={field.name}>
                      <label htmlFor={field.name} className="block text-sm font-medium text-gray-700">
                        {field.name} {field.required && <span className="text-red-500">*</span>}
                      </label>
                      
                      {field.type === 'string' && (
                        <input
                          type="text"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          defaultValue={item?.payload.data?.[field.name] || ''}
                          onChange={(e) => handlePayloadChange(field.name, e.target.value)}
                        />
                      )}
                      
                      {field.type === 'number' && (
                        <input
                          type="number"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          defaultValue={item?.payload.data?.[field.name] || 0}
                          onChange={(e) => handlePayloadChange(field.name, parseFloat(e.target.value))}
                        />
                      )}
                      
                      {field.type === 'boolean' && (
                        <div className="mt-1">
                          <input
                            type="checkbox"
                            id={field.name}
                            className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                            defaultChecked={item?.payload.data?.[field.name] || false}
                            onChange={(e) => handlePayloadChange(field.name, e.target.checked)}
                          />
                          <label htmlFor={field.name} className="ml-2 text-sm text-gray-700">
                            Enabled
                          </label>
                        </div>
                      )}
                      
                      {field.type === 'date' && (
                        <input
                          type="date"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          defaultValue={item?.payload.data?.[field.name] || ''}
                          onChange={(e) => handlePayloadChange(field.name, e.target.value)}
                        />
                      )}
                      
                      {field.description && (
                        <p className="mt-1 text-sm text-gray-500">{field.description}</p>
                      )}
                    </div>
                  ))}
                  
                  <div className="mt-1">
                    <input
                      type="checkbox"
                      id="includePdf"
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      defaultChecked={item?.payload.includePdf !== false}
                      onChange={(e) => {
                        const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
                        setValue('payload', { ...currentPayload, includePdf: e.target.checked });
                      }}
                    />
                    <label htmlFor="includePdf" className="ml-2 text-sm text-gray-700">
                      Include PDF
                    </label>
                    <p className="mt-1 text-sm text-gray-500">
                      If checked, the response will include a PDF download link.
                    </p>
                  </div>
                </>
              )}
            </div>
            
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => router.push(`/items/${itemId}`)}
                className="mr-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </AppLayout>
  );
}
