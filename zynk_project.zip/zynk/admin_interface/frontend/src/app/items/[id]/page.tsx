import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import AppLayout from '../../../components/AppLayout';
import { itemsApi, Item } from '../../../api/api';

export default function ItemDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<any | null>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [testError, setTestError] = useState<string | null>(null);
  
  const itemId = params.id as string;
  
  useEffect(() => {
    const fetchItem = async () => {
      try {
        setLoading(true);
        const response = await itemsApi.getItem(itemId);
        setItem(response.data.item);
      } catch (err: any) {
        console.error('Error fetching item:', err);
        setError('Failed to load item. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    if (itemId) {
      fetchItem();
    }
  }, [itemId]);
  
  const handleTest = async () => {
    try {
      setTestLoading(true);
      setTestError(null);
      setTestResult(null);
      
      const response = await itemsApi.testItem(itemId);
      setTestResult(response.data.result);
    } catch (err: any) {
      console.error('Error testing item:', err);
      setTestError(err.response?.data?.message || 'Failed to test item. Please try again.');
    } finally {
      setTestLoading(false);
    }
  };
  
  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await itemsApi.deleteItem(itemId);
        router.push('/items');
      } catch (err: any) {
        console.error('Error deleting item:', err);
        alert('Failed to delete item. Please try again.');
      }
    }
  };
  
  if (loading) {
    return (
      <AppLayout>
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500">Loading...</p>
        </div>
      </AppLayout>
    );
  }
  
  if (error || !item) {
    return (
      <AppLayout>
        <div className="bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error || 'Item not found'}</p>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">{item.name}</h1>
          <div className="flex space-x-3">
            <button
              onClick={() => router.push(`/items/${itemId}/edit`)}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="-ml-1 mr-2 h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
              </svg>
              Edit
            </button>
            <button
              onClick={handleDelete}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="-ml-1 mr-2 h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              Delete
            </button>
          </div>
        </div>
        
        {/* Item Details */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Item Details</h2>
          </div>
          
          <div className="p-6">
            <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
              <div>
                <dt className="text-sm font-medium text-gray-500">Name</dt>
                <dd className="mt-1 text-sm text-gray-900">{item.name}</dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Document Type</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    {item.templateInfo.documentType}
                  </span>
                </dd>
              </div>
              
              <div className="sm:col-span-2">
                <dt className="text-sm font-medium text-gray-500">Description</dt>
                <dd className="mt-1 text-sm text-gray-900">{item.description}</dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Created</dt>
                <dd className="mt-1 text-sm text-gray-900">{new Date(item.createdAt).toLocaleString()}</dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Last Updated</dt>
                <dd className="mt-1 text-sm text-gray-900">{new Date(item.updatedAt).toLocaleString()}</dd>
              </div>
              
              <div className="sm:col-span-2">
                <dt className="text-sm font-medium text-gray-500">Template Info</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  <ul className="border rounded-md divide-y divide-gray-200">
                    <li className="pl-3 pr-4 py-2 flex items-center justify-between text-sm">
                      <div className="w-0 flex-1 flex items-center">
                        <span className="ml-2 flex-1 w-0 truncate">Space ID</span>
                      </div>
                      <div className="ml-4 flex-shrink-0 font-mono">
                        {item.templateInfo.spaceId}
                      </div>
                    </li>
                    <li className="pl-3 pr-4 py-2 flex items-center justify-between text-sm">
                      <div className="w-0 flex-1 flex items-center">
                        <span className="ml-2 flex-1 w-0 truncate">Asset ID</span>
                      </div>
                      <div className="ml-4 flex-shrink-0 font-mono">
                        {item.templateInfo.assetId}
                      </div>
                    </li>
                  </ul>
                </dd>
              </div>
            </dl>
          </div>
        </div>
        
        {/* Payload */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">DocGen API Payload</h2>
          </div>
          
          <div className="p-6">
            <pre className="bg-gray-50 p-4 rounded-md overflow-auto text-sm font-mono">
              {JSON.stringify(item.payload, null, 2)}
            </pre>
          </div>
          
          <div className="px-6 py-4 border-t bg-gray-50">
            <button
              onClick={handleTest}
              disabled={testLoading}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
            >
              {testLoading ? 'Testing...' : 'Test with DocGen API'}
            </button>
          </div>
        </div>
        
        {/* Test Results */}
        {(testResult || testError) && (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="px-6 py-4 border-b">
              <h2 className="text-lg font-semibold text-gray-800">Test Results</h2>
            </div>
            
            <div className="p-6">
              {testError ? (
                <div className="bg-red-50 border-l-4 border-red-500 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-red-700">{testError}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-green-700">Test successful! Document generated.</p>
                      </div>
                    </div>
                  </div>
                  
                  <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <dt className="text-sm font-medium text-gray-500">Download URL</dt>
                      <dd className="mt-1 text-sm text-gray-900">
                        <a 
                          href={testResult.downloadUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:text-primary-900"
                        >
                          {testResult.downloadUrl}
                        </a>
                      </dd>
                    </div>
                    
                    {testResult.pdfDownloadUrl && (
                      <div className="sm:col-span-2">
                        <dt className="text-sm font-medium text-gray-500">PDF Download URL</dt>
                        <dd className="mt-1 text-sm text-gray-900">
                          <a 
                            href={testResult.pdfDownloadUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary-600 hover:text-primary-900"
                          >
                            {testResult.pdfDownloadUrl}
                          </a>
                        </dd>
                      </div>
                    )}
                    
                    <div>
                      <dt className="text-sm font-medium text-gray-500">File Size</dt>
                      <dd className="mt-1 text-sm text-gray-900">{testResult.fileSize} bytes</dd>
                    </div>
                    
                    <div>
                      <dt className="text-sm font-medium text-gray-500">MIME Type</dt>
                      <dd className="mt-1 text-sm text-gray-900">{testResult.mimeType}</dd>
                    </div>
                    
                    <div>
                      <dt className="text-sm font-medium text-gray-500">File Extension</dt>
                      <dd className="mt-1 text-sm text-gray-900">{testResult.fileExtension}</dd>
                    </div>
                    
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Checksum</dt>
                      <dd className="mt-1 text-sm font-mono text-gray-900">{testResult.checksum}</dd>
                    </div>
                  </dl>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
