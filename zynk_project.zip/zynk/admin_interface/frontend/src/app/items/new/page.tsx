import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useRouter } from 'next/navigation';
import AppLayout from '../../components/AppLayout';
import { itemsApi, templatesApi, Template } from '../../api/api';

// Define validation schema
const itemSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().min(1, 'Description is required'),
  templateId: z.string().min(1, 'Template is required'),
  payload: z.record(z.any()).optional(),
});

type ItemFormData = z.infer<typeof itemSchema>;

export default function NewItemPage() {
  const router = useRouter();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  
  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    setValue,
    watch
  } = useForm<ItemFormData>({
    resolver: zodResolver(itemSchema),
    defaultValues: {
      payload: {
        email: '',
        data: {},
        includePdf: true
      }
    }
  });
  
  const templateId = watch('templateId');
  
  // Fetch templates
  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const response = await templatesApi.getTemplates();
        setTemplates(response.data.templates);
      } catch (err: any) {
        console.error('Error fetching templates:', err);
        setError('Failed to load templates. Please try again.');
      }
    };
    
    fetchTemplates();
  }, []);
  
  // Update selected template when templateId changes
  useEffect(() => {
    if (templateId) {
      const template = templates.find(t => t._id === templateId) || null;
      setSelectedTemplate(template);
      
      // Update payload with template-specific fields
      if (template) {
        const data: Record<string, any> = {};
        template.fields.forEach(field => {
          // Set default values based on field type
          switch (field.type) {
            case 'string':
              data[field.name] = '';
              break;
            case 'number':
              data[field.name] = 0;
              break;
            case 'boolean':
              data[field.name] = false;
              break;
            case 'date':
              data[field.name] = new Date().toISOString().split('T')[0];
              break;
            case 'object':
              data[field.name] = {};
              break;
            case 'array':
              data[field.name] = [];
              break;
          }
        });
        
        setValue('payload', {
          email: '',
          data,
          includePdf: true
        });
      }
    }
  }, [templateId, templates, setValue]);
  
  const onSubmit = async (data: ItemFormData) => {
    if (!selectedTemplate) {
      setError('Please select a template');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      const template = templates.find(t => t._id === data.templateId);
      if (!template) {
        throw new Error('Template not found');
      }
      
      const response = await itemsApi.createItem({
        name: data.name,
        description: data.description,
        templateInfo: {
          spaceId: template.spaceId,
          assetId: template.assetId,
          documentType: template.documentType
        },
        payload: data.payload
      });
      
      // Redirect to items list
      router.push('/items');
    } catch (err: any) {
      console.error('Error creating item:', err);
      setError(err.response?.data?.message || 'Failed to create item. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handlePayloadChange = (field: string, value: any) => {
    const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
    const newData = { ...currentPayload.data, [field]: value };
    setValue('payload', { ...currentPayload, data: newData });
  };
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Create New Item</h1>
          <button
            onClick={() => router.push('/items')}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            Cancel
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Item Details</h2>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  id="name"
                  className={`mt-1 block w-full border ${errors.name ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  {...register('name')}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                <textarea
                  id="description"
                  rows={3}
                  className={`mt-1 block w-full border ${errors.description ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  {...register('description')}
                />
                {errors.description && (
                  <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="templateId" className="block text-sm font-medium text-gray-700">Template</label>
                <select
                  id="templateId"
                  className={`mt-1 block w-full border ${errors.templateId ? 'border-red-300' : 'border-gray-300'} rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  {...register('templateId')}
                >
                  <option value="">Select a template</option>
                  {templates.map((template) => (
                    <option key={template._id} value={template._id}>
                      {template.name} ({template.documentType})
                    </option>
                  ))}
                </select>
                {errors.templateId && (
                  <p className="mt-1 text-sm text-red-600">{errors.templateId.message}</p>
                )}
              </div>
              
              {selectedTemplate && (
                <>
                  <div className="border-t pt-4">
                    <h3 className="text-lg font-medium text-gray-900">Template Data</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Enter the data that will be used to generate the document.
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                      onChange={(e) => {
                        const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
                        setValue('payload', { ...currentPayload, email: e.target.value });
                      }}
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Email address to identify user in Templafy.
                    </p>
                  </div>
                  
                  {selectedTemplate.fields.map((field) => (
                    <div key={field.name}>
                      <label htmlFor={field.name} className="block text-sm font-medium text-gray-700">
                        {field.name} {field.required && <span className="text-red-500">*</span>}
                      </label>
                      
                      {field.type === 'string' && (
                        <input
                          type="text"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          onChange={(e) => handlePayloadChange(field.name, e.target.value)}
                        />
                      )}
                      
                      {field.type === 'number' && (
                        <input
                          type="number"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          onChange={(e) => handlePayloadChange(field.name, parseFloat(e.target.value))}
                        />
                      )}
                      
                      {field.type === 'boolean' && (
                        <div className="mt-1">
                          <input
                            type="checkbox"
                            id={field.name}
                            className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                            onChange={(e) => handlePayloadChange(field.name, e.target.checked)}
                          />
                          <label htmlFor={field.name} className="ml-2 text-sm text-gray-700">
                            Enabled
                          </label>
                        </div>
                      )}
                      
                      {field.type === 'date' && (
                        <input
                          type="date"
                          id={field.name}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                          onChange={(e) => handlePayloadChange(field.name, e.target.value)}
                        />
                      )}
                      
                      {field.description && (
                        <p className="mt-1 text-sm text-gray-500">{field.description}</p>
                      )}
                    </div>
                  ))}
                  
                  <div className="mt-1">
                    <input
                      type="checkbox"
                      id="includePdf"
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      defaultChecked={true}
                      onChange={(e) => {
                        const currentPayload = watch('payload') || { email: '', data: {}, includePdf: true };
                        setValue('payload', { ...currentPayload, includePdf: e.target.checked });
                      }}
                    />
                    <label htmlFor="includePdf" className="ml-2 text-sm text-gray-700">
                      Include PDF
                    </label>
                    <p className="mt-1 text-sm text-gray-500">
                      If checked, the response will include a PDF download link.
                    </p>
                  </div>
                </>
              )}
            </div>
            
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => router.push('/items')}
                className="mr-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
              >
                {loading ? 'Creating...' : 'Create Item'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </AppLayout>
  );
}
