import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import AppLayout from '../../components/AppLayout';
import axios from 'axios';

export default function SyncPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [lastSync, setLastSync] = useState<string | null>(null);

  const handleSync = async (type: 'items' | 'templates' | 'all') => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);
      
      const response = await axios.post(`/api/sync/${type}`);
      
      setSuccess(`Successfully synced ${type}. ${response.data.message || ''}`);
      setLastSync(new Date().toLocaleString());
    } catch (err: any) {
      console.error(`Sync ${type} error:`, err);
      setError(err.response?.data?.message || `Failed to sync ${type}. Please try again.`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Sync with Content Connector</h1>
        </div>
        
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}
        
        {success && (
          <div className="bg-green-50 border-l-4 border-green-500 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-green-700">{success}</p>
              </div>
            </div>
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Synchronization Options</h2>
          </div>
          
          <div className="p-6 space-y-6">
            <p className="text-gray-700">
              Synchronize data between the Admin Interface and the Content Connector to make items available in Templafy.
            </p>
            
            {lastSync && (
              <p className="text-sm text-gray-500">
                Last synchronized: {lastSync}
              </p>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Sync Items</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Synchronize all items to the Content Connector.
                </p>
                <button
                  onClick={() => handleSync('items')}
                  disabled={loading}
                  className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
                >
                  {loading ? 'Syncing...' : 'Sync Items'}
                </button>
              </div>
              
              <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Sync Templates</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Synchronize all templates to the Content Connector.
                </p>
                <button
                  onClick={() => handleSync('templates')}
                  disabled={loading}
                  className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
                >
                  {loading ? 'Syncing...' : 'Sync Templates'}
                </button>
              </div>
              
              <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Sync All</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Synchronize all data to the Content Connector.
                </p>
                <button
                  onClick={() => handleSync('all')}
                  disabled={loading}
                  className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                >
                  {loading ? 'Syncing...' : 'Sync All Data'}
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">About Synchronization</h2>
          </div>
          
          <div className="p-6">
            <div className="prose max-w-none">
              <p>
                The synchronization process copies data from the Admin Interface to the Content Connector, making it available to Templafy users.
              </p>
              
              <h3>When to synchronize:</h3>
              <ul>
                <li>After creating or updating items</li>
                <li>After adding new templates</li>
                <li>When changes are not appearing in Templafy</li>
              </ul>
              
              <p>
                <strong>Note:</strong> Synchronization is one-way from the Admin Interface to the Content Connector. Changes made in Templafy will not be reflected back in the Admin Interface.
              </p>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
