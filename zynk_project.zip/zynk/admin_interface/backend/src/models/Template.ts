import mongoose, { Document, Schema } from 'mongoose';

export interface ITemplate extends Document {
  spaceId: string;
  assetId: string;
  name: string;
  description: string;
  documentType: string;
  fields: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

const TemplateSchema: Schema = new Schema({
  spaceId: { 
    type: String, 
    required: true 
  },
  assetId: { 
    type: String, 
    required: true 
  },
  name: { 
    type: String, 
    required: true,
    trim: true
  },
  description: { 
    type: String, 
    required: false 
  },
  documentType: { 
    type: String, 
    required: true,
    enum: ['document', 'presentation', 'spreadsheet', 'text-element']
  },
  fields: [{
    name: { 
      type: String, 
      required: true 
    },
    type: { 
      type: String, 
      required: true,
      enum: ['string', 'number', 'boolean', 'date', 'object', 'array']
    },
    required: { 
      type: Boolean, 
      default: false 
    },
    description: { 
      type: String, 
      required: false 
    }
  }]
}, {
  timestamps: true
});

// Add text index for search functionality
TemplateSchema.index({ name: 'text', description: 'text' });

export default mongoose.model<ITemplate>('Template', TemplateSchema);
