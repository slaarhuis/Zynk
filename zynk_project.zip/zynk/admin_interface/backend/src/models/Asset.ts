import mongoose, { Document, Schema } from 'mongoose';

export interface IAsset extends Document {
  name: string;
  description: string;
  mimeType: string;
  tags: string;
  filePath: string;
  previewUrl: string;
  altText?: string;
  createdBy: mongoose.Types.ObjectId;
  updatedBy: mongoose.Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

const AssetSchema: Schema = new Schema({
  name: { 
    type: String, 
    required: true,
    trim: true
  },
  description: { 
    type: String, 
    required: false 
  },
  mimeType: { 
    type: String, 
    required: true 
  },
  tags: { 
    type: String, 
    required: false 
  },
  filePath: { 
    type: String, 
    required: true 
  },
  previewUrl: { 
    type: String, 
    required: true 
  },
  altText: { 
    type: String, 
    required: false 
  },
  createdBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  updatedBy: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Add text index for search functionality
AssetSchema.index({ name: 'text', description: 'text', tags: 'text' });

export default mongoose.model<IAsset>('Asset', AssetSchema);
