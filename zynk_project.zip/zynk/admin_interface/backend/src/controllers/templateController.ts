import { Request, Response } from 'express';
import Template, { ITemplate } from '../models/Template';
import axios from 'axios';

// Get all templates with pagination and filtering
export const getTemplates = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;
    const search = req.query.search as string;
    
    // Build query
    let query: any = {};
    
    // Add search if provided
    if (search) {
      query = { $text: { $search: search } };
    }
    
    // Execute query with pagination
    const templates = await Template.find(query)
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // Get total count for pagination
    const total = await Template.countDocuments(query);
    
    res.status(200).json({
      templates,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get templates error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get template by ID
export const getTemplateById = async (req: Request, res: Response) => {
  try {
    const template = await Template.findById(req.params.id);
    
    if (!template) {
      return res.status(404).json({ message: 'Template not found' });
    }
    
    res.status(200).json({ template });
  } catch (error) {
    console.error('Get template error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Create new template
export const createTemplate = async (req: Request, res: Response) => {
  try {
    const { spaceId, assetId, name, description, documentType, fields } = req.body;
    
    // Create new template
    const template = new Template({
      spaceId,
      assetId,
      name,
      description,
      documentType,
      fields
    });
    
    await template.save();
    
    res.status(201).json({
      message: 'Template created successfully',
      template
    });
  } catch (error) {
    console.error('Create template error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update template
export const updateTemplate = async (req: Request, res: Response) => {
  try {
    const { spaceId, assetId, name, description, documentType, fields } = req.body;
    
    // Find template
    const template = await Template.findById(req.params.id);
    
    if (!template) {
      return res.status(404).json({ message: 'Template not found' });
    }
    
    // Update template
    template.spaceId = spaceId || template.spaceId;
    template.assetId = assetId || template.assetId;
    template.name = name || template.name;
    template.description = description || template.description;
    template.documentType = documentType || template.documentType;
    if (fields) {
      template.fields = fields;
    }
    
    await template.save();
    
    res.status(200).json({
      message: 'Template updated successfully',
      template
    });
  } catch (error) {
    console.error('Update template error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete template
export const deleteTemplate = async (req: Request, res: Response) => {
  try {
    const template = await Template.findById(req.params.id);
    
    if (!template) {
      return res.status(404).json({ message: 'Template not found' });
    }
    
    await template.remove();
    
    res.status(200).json({
      message: 'Template deleted successfully'
    });
  } catch (error) {
    console.error('Delete template error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Sync templates from Templafy
export const syncTemplates = async (req: Request, res: Response) => {
  try {
    // Get Templafy API token from environment or database
    const templafyApiToken = process.env.TEMPLAFY_API_TOKEN;
    
    if (!templafyApiToken) {
      return res.status(500).json({ message: 'Templafy API token not configured' });
    }
    
    const tenantId = process.env.TEMPLAFY_TENANT_ID || 'your-tenant';
    
    // Get spaces
    const spacesResponse = await axios.get(
      `https://${tenantId}.api.templafy.com/v3/spaces`,
      {
        headers: {
          'Authorization': `Bearer ${templafyApiToken}`
        }
      }
    );
    
    const spaces = spacesResponse.data.spaces;
    const templates: ITemplate[] = [];
    
    // For each space, get templates
    for (const space of spaces) {
      // Get document templates
      try {
        const documentsResponse = await axios.get(
          `https://${tenantId}.api.templafy.com/v3/libraries/${space.id}/documents/assets`,
          {
            headers: {
              'Authorization': `Bearer ${templafyApiToken}`
            }
          }
        );
        
        for (const doc of documentsResponse.data.assets) {
          templates.push({
            spaceId: space.id,
            assetId: doc.id,
            name: doc.name,
            description: doc.description || '',
            documentType: 'document',
            fields: [] // Would need to be determined from template metadata
          } as ITemplate);
        }
      } catch (error) {
        console.error(`Error fetching document templates for space ${space.id}:`, error);
      }
      
      // Get presentation templates
      try {
        const presentationsResponse = await axios.get(
          `https://${tenantId}.api.templafy.com/v3/libraries/${space.id}/presentations/assets`,
          {
            headers: {
              'Authorization': `Bearer ${templafyApiToken}`
            }
          }
        );
        
        for (const pres of presentationsResponse.data.assets) {
          templates.push({
            spaceId: space.id,
            assetId: pres.id,
            name: pres.name,
            description: pres.description || '',
            documentType: 'presentation',
            fields: [] // Would need to be determined from template metadata
          } as ITemplate);
        }
      } catch (error) {
        console.error(`Error fetching presentation templates for space ${space.id}:`, error);
      }
      
      // Similar for spreadsheets and text-elements
    }
    
    // Save templates to database (upsert)
    for (const template of templates) {
      await Template.findOneAndUpdate(
        { spaceId: template.spaceId, assetId: template.assetId },
        template,
        { upsert: true, new: true }
      );
    }
    
    res.status(200).json({
      message: 'Templates synced successfully',
      count: templates.length
    });
  } catch (error) {
    console.error('Sync templates error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
