import { Request, Response } from 'express';
import Item, { IItem } from '../models/Item';
import Template from '../models/Template';
import axios from 'axios';

// Get all items with pagination and filtering
export const getItems = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;
    const search = req.query.search as string;
    
    // Build query
    let query: any = {};
    
    // Add search if provided
    if (search) {
      query = { $text: { $search: search } };
    }
    
    // Execute query with pagination
    const items = await Item.find(query)
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('createdBy', 'firstName lastName email')
      .populate('updatedBy', 'firstName lastName email');
    
    // Get total count for pagination
    const total = await Item.countDocuments(query);
    
    res.status(200).json({
      items,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get items error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get item by ID
export const getItemById = async (req: Request, res: Response) => {
  try {
    const item = await Item.findById(req.params.id)
      .populate('createdBy', 'firstName lastName email')
      .populate('updatedBy', 'firstName lastName email');
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    res.status(200).json({ item });
  } catch (error) {
    console.error('Get item error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Create new item
export const createItem = async (req: Request, res: Response) => {
  try {
    const { name, description, templateInfo, payload } = req.body;
    
    if (!req.userId) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    // Validate template exists
    const template = await Template.findOne({
      spaceId: templateInfo.spaceId,
      assetId: templateInfo.assetId
    });
    
    if (!template) {
      return res.status(400).json({ message: 'Template not found' });
    }
    
    // Create new item
    const item = new Item({
      name,
      description,
      templateInfo,
      payload,
      createdBy: req.userId,
      updatedBy: req.userId
    });
    
    await item.save();
    
    res.status(201).json({
      message: 'Item created successfully',
      item
    });
  } catch (error) {
    console.error('Create item error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update item
export const updateItem = async (req: Request, res: Response) => {
  try {
    const { name, description, templateInfo, payload } = req.body;
    
    if (!req.userId) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    // Find item
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    // Validate template exists if changed
    if (templateInfo && (
      templateInfo.spaceId !== item.templateInfo.spaceId ||
      templateInfo.assetId !== item.templateInfo.assetId
    )) {
      const template = await Template.findOne({
        spaceId: templateInfo.spaceId,
        assetId: templateInfo.assetId
      });
      
      if (!template) {
        return res.status(400).json({ message: 'Template not found' });
      }
    }
    
    // Update item
    item.name = name || item.name;
    item.description = description || item.description;
    if (templateInfo) {
      item.templateInfo = templateInfo;
    }
    if (payload) {
      item.payload = payload;
    }
    item.updatedBy = req.userId;
    
    await item.save();
    
    res.status(200).json({
      message: 'Item updated successfully',
      item
    });
  } catch (error) {
    console.error('Update item error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete item
export const deleteItem = async (req: Request, res: Response) => {
  try {
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    await item.remove();
    
    res.status(200).json({
      message: 'Item deleted successfully'
    });
  } catch (error) {
    console.error('Delete item error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Test item with DocGen API
export const testItem = async (req: Request, res: Response) => {
  try {
    const item = await Item.findById(req.params.id);
    
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    // Get Templafy API token from environment or database
    const templafyApiToken = process.env.TEMPLAFY_API_TOKEN;
    
    if (!templafyApiToken) {
      return res.status(500).json({ message: 'Templafy API token not configured' });
    }
    
    // Construct API URL based on document type
    const tenantId = process.env.TEMPLAFY_TENANT_ID || 'your-tenant';
    let apiUrl = '';
    
    switch (item.templateInfo.documentType) {
      case 'document':
        apiUrl = `https://${tenantId}.api.templafy.com/v2/libraries/${item.templateInfo.spaceId}/documents/assets/${item.templateInfo.assetId}/generate`;
        break;
      case 'presentation':
        apiUrl = `https://${tenantId}.api.templafy.com/v2/libraries/${item.templateInfo.spaceId}/presentations/assets/${item.templateInfo.assetId}/generate`;
        break;
      case 'spreadsheet':
        apiUrl = `https://${tenantId}.api.templafy.com/v2/libraries/${item.templateInfo.spaceId}/spreadsheets/assets/${item.templateInfo.assetId}/generate`;
        break;
      case 'text-element':
        apiUrl = `https://${tenantId}.api.templafy.com/v2/libraries/${item.templateInfo.spaceId}/text-elements/assets/${item.templateInfo.assetId}/generate`;
        break;
      default:
        return res.status(400).json({ message: 'Invalid document type' });
    }
    
    // Make API request to Templafy
    const response = await axios.post(
      apiUrl,
      item.payload,
      {
        headers: {
          'Authorization': `Bearer ${templafyApiToken}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    res.status(200).json({
      message: 'Test successful',
      result: response.data
    });
  } catch (error: any) {
    console.error('Test item error:', error);
    
    // Handle API errors
    if (error.response) {
      return res.status(error.response.status).json({
        message: 'Templafy API error',
        error: error.response.data
      });
    }
    
    res.status(500).json({ message: 'Server error' });
  }
};
