import { Request, Response } from 'express';
import axios from 'axios';

/**
 * Controller for the admin interface to trigger sync operations on the content connector
 */
export const syncController = {
  // Trigger sync of items from admin interface to content connector
  triggerSyncItems: async (req: Request, res: Response) => {
    try {
      const contentConnectorUrl = process.env.CONTENT_CONNECTOR_URL || 'http://localhost:5000/api';
      const apiKey = process.env.CONTENT_CONNECTOR_API_KEY || '';
      
      const response = await axios.post(
        `${contentConnectorUrl}/sync/items`,
        {},
        {
          headers: {
            'Authorization': `ApiKey ${apiKey}`
          }
        }
      );
      
      res.status(200).json(response.data);
    } catch (error: any) {
      console.error('Trigger sync items error:', error);
      res.status(500).json({ 
        message: 'Failed to sync items to content connector',
        error: error.response?.data || error.message
      });
    }
  },
  
  // Trigger sync of templates from admin interface to content connector
  triggerSyncTemplates: async (req: Request, res: Response) => {
    try {
      const contentConnectorUrl = process.env.CONTENT_CONNECTOR_URL || 'http://localhost:5000/api';
      const apiKey = process.env.CONTENT_CONNECTOR_API_KEY || '';
      
      const response = await axios.post(
        `${contentConnectorUrl}/sync/templates`,
        {},
        {
          headers: {
            'Authorization': `ApiKey ${apiKey}`
          }
        }
      );
      
      res.status(200).json(response.data);
    } catch (error: any) {
      console.error('Trigger sync templates error:', error);
      res.status(500).json({ 
        message: 'Failed to sync templates to content connector',
        error: error.response?.data || error.message
      });
    }
  },
  
  // Trigger sync of all data from admin interface to content connector
  triggerSyncAll: async (req: Request, res: Response) => {
    try {
      const contentConnectorUrl = process.env.CONTENT_CONNECTOR_URL || 'http://localhost:5000/api';
      const apiKey = process.env.CONTENT_CONNECTOR_API_KEY || '';
      
      const response = await axios.post(
        `${contentConnectorUrl}/sync/all`,
        {},
        {
          headers: {
            'Authorization': `ApiKey ${apiKey}`
          }
        }
      );
      
      res.status(200).json(response.data);
    } catch (error: any) {
      console.error('Trigger sync all error:', error);
      res.status(500).json({ 
        message: 'Failed to sync data to content connector',
        error: error.response?.data || error.message
      });
    }
  }
};
