import { Request, Response } from 'express';
import Asset, { IAsset } from '../models/Asset';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';

// Get all assets with pagination and filtering
export const getAssets = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;
    const search = req.query.search as string;
    
    // Build query
    let query: any = {};
    
    // Add search if provided
    if (search) {
      query = { $text: { $search: search } };
    }
    
    // Execute query with pagination
    const assets = await Asset.find(query)
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('createdBy', 'firstName lastName email')
      .populate('updatedBy', 'firstName lastName email');
    
    // Get total count for pagination
    const total = await Asset.countDocuments(query);
    
    res.status(200).json({
      assets,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get assets error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get asset by ID
export const getAssetById = async (req: Request, res: Response) => {
  try {
    const asset = await Asset.findById(req.params.id)
      .populate('createdBy', 'firstName lastName email')
      .populate('updatedBy', 'firstName lastName email');
    
    if (!asset) {
      return res.status(404).json({ message: 'Asset not found' });
    }
    
    res.status(200).json({ asset });
  } catch (error) {
    console.error('Get asset error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Create new asset
export const createAsset = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'File is required' });
    }
    
    if (!req.userId) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    const { name, description, tags, altText } = req.body;
    
    // Determine mime type
    const mimeType = req.file.mimetype;
    
    // Generate file paths
    const uploadsDir = path.join(__dirname, '../../uploads');
    const assetsDir = path.join(uploadsDir, 'assets');
    const previewsDir = path.join(uploadsDir, 'previews');
    
    // Ensure directories exist
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir);
    }
    if (!fs.existsSync(assetsDir)) {
      fs.mkdirSync(assetsDir);
    }
    if (!fs.existsSync(previewsDir)) {
      fs.mkdirSync(previewsDir);
    }
    
    // Generate unique filename
    const fileId = uuidv4();
    const fileExt = path.extname(req.file.originalname);
    const fileName = `${fileId}${fileExt}`;
    
    // Save file
    const filePath = path.join(assetsDir, fileName);
    fs.writeFileSync(filePath, req.file.buffer);
    
    // For simplicity, use the same file for preview
    // In a production environment, you would generate a thumbnail
    const previewPath = path.join(previewsDir, fileName);
    fs.writeFileSync(previewPath, req.file.buffer);
    
    // Create asset record
    const asset = new Asset({
      name: name || req.file.originalname,
      description: description || '',
      mimeType,
      tags: tags || '',
      filePath: `/uploads/assets/${fileName}`,
      previewUrl: `/uploads/previews/${fileName}`,
      altText: altText || '',
      createdBy: req.userId,
      updatedBy: req.userId
    });
    
    await asset.save();
    
    res.status(201).json({
      message: 'Asset created successfully',
      asset
    });
  } catch (error) {
    console.error('Create asset error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update asset
export const updateAsset = async (req: Request, res: Response) => {
  try {
    const { name, description, tags, altText } = req.body;
    
    if (!req.userId) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    // Find asset
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return res.status(404).json({ message: 'Asset not found' });
    }
    
    // Update asset
    if (name) asset.name = name;
    if (description !== undefined) asset.description = description;
    if (tags !== undefined) asset.tags = tags;
    if (altText !== undefined) asset.altText = altText;
    asset.updatedBy = req.userId;
    
    // If file is provided, update file
    if (req.file) {
      // Determine mime type
      asset.mimeType = req.file.mimetype;
      
      // Generate file paths
      const assetsDir = path.join(__dirname, '../../uploads/assets');
      const previewsDir = path.join(__dirname, '../../uploads/previews');
      
      // Extract existing filename
      const existingFileName = path.basename(asset.filePath);
      
      // Save file
      const filePath = path.join(assetsDir, existingFileName);
      fs.writeFileSync(filePath, req.file.buffer);
      
      // For simplicity, use the same file for preview
      const previewPath = path.join(previewsDir, existingFileName);
      fs.writeFileSync(previewPath, req.file.buffer);
    }
    
    await asset.save();
    
    res.status(200).json({
      message: 'Asset updated successfully',
      asset
    });
  } catch (error) {
    console.error('Update asset error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete asset
export const deleteAsset = async (req: Request, res: Response) => {
  try {
    const asset = await Asset.findById(req.params.id);
    
    if (!asset) {
      return res.status(404).json({ message: 'Asset not found' });
    }
    
    // Delete files
    try {
      const filePath = path.join(__dirname, '../..', asset.filePath);
      const previewPath = path.join(__dirname, '../..', asset.previewUrl);
      
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      
      if (fs.existsSync(previewPath)) {
        fs.unlinkSync(previewPath);
      }
    } catch (fileError) {
      console.error('Error deleting files:', fileError);
    }
    
    // Delete record
    await asset.remove();
    
    res.status(200).json({
      message: 'Asset deleted successfully'
    });
  } catch (error) {
    console.error('Delete asset error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
