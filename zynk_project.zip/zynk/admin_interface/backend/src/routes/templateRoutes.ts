import { Router } from 'express';
import { 
  getTemplates, 
  getTemplateById, 
  createTemplate, 
  updateTemplate, 
  deleteTemplate,
  syncTemplates
} from '../controllers/templateController';
import { auth, requireRole } from '../middleware/auth';

const router = Router();

// Protected routes - require authentication
router.get('/', auth, getTemplates);
router.get('/:id', auth, getTemplateById);
router.post('/', auth, requireRole(['admin']), createTemplate);
router.put('/:id', auth, requireRole(['admin']), updateTemplate);
router.delete('/:id', auth, requireRole(['admin']), deleteTemplate);
router.post('/sync', auth, requireRole(['admin']), syncTemplates);

export default router;
