import { Router } from 'express';
import { 
  getItems, 
  getItemById, 
  createItem, 
  updateItem, 
  deleteItem, 
  testItem 
} from '../controllers/itemController';
import { auth, requireRole } from '../middleware/auth';

const router = Router();

// Protected routes - require authentication
router.get('/', auth, getItems);
router.get('/:id', auth, getItemById);
router.post('/', auth, requireRole(['admin', 'editor']), createItem);
router.put('/:id', auth, requireRole(['admin', 'editor']), updateItem);
router.delete('/:id', auth, requireRole(['admin']), deleteItem);
router.post('/:id/test', auth, testItem);

export default router;
