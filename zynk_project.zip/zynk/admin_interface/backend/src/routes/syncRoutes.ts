import { Router } from 'express';
import { syncController } from '../controllers/syncController';
import { auth, requireRole } from '../middleware/auth';

const router = Router();

// Protected routes - require authentication and admin role
router.post('/items', auth, requireRole(['admin']), syncController.triggerSyncItems);
router.post('/templates', auth, requireRole(['admin']), syncController.triggerSyncTemplates);
router.post('/all', auth, requireRole(['admin']), syncController.triggerSyncAll);

export default router;
