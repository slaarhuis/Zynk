import { Router } from 'express';
import { login, register, refreshToken, getProfile } from '../controllers/authController';
import { auth, requireRole } from '../middleware/auth';

const router = Router();

// Public routes
router.post('/login', login);
router.post('/refresh-token', refreshToken);

// Protected routes
router.get('/profile', auth, getProfile);

// Admin-only routes
router.post('/register', auth, requireRole(['admin']), register);

export default router;
