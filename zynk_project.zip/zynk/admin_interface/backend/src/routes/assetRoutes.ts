import { Router } from 'express';
import multer from 'multer';
import { 
  getAssets, 
  getAssetById, 
  createAsset, 
  updateAsset, 
  deleteAsset 
} from '../controllers/assetController';
import { auth, requireRole } from '../middleware/auth';

// Configure multer for memory storage
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

const router = Router();

// Protected routes - require authentication
router.get('/', auth, getAssets);
router.get('/:id', auth, getAssetById);
router.post('/', auth, requireRole(['admin', 'editor']), upload.single('file'), createAsset);
router.put('/:id', auth, requireRole(['admin', 'editor']), upload.single('file'), updateAsset);
router.delete('/:id', auth, requireRole(['admin']), deleteAsset);

export default router;
