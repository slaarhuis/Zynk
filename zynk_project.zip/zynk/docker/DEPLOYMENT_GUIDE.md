# Zynk Deployment Guide for Synology NAS

This guide provides instructions for deploying the Zynk application on a Synology NAS using Docker.

## Prerequisites

1. A Synology NAS with Docker package installed
2. Docker Compose installed on your Synology NAS
3. Basic knowledge of Docker and Synology DSM

## Setup Instructions

### 1. Prepare Your Synology NAS

1. Install Docker from the Synology Package Center if not already installed
2. Enable SSH access to your NAS (Control Panel > Terminal & SNMP > Enable SSH service)
3. Create a shared folder for Zynk data (e.g., "zynk")

### 2. Copy Files to Your NAS

1. Copy the entire `zynk` directory to your Synology NAS shared folder
2. The directory structure should look like:
   ```
   zynk/
   ├── admin_interface/
   │   ├── backend/
   │   └── frontend/
   ├── content_connector/
   └── docker/
       ├── docker-compose.yml
       └── .env
   ```

### 3. Configure Environment Variables

1. SSH into your Synology NAS
2. Navigate to the docker directory: `cd /volume1/your-shared-folder/zynk/docker`
3. Copy the example environment file: `cp .env.example .env`
4. Edit the `.env` file to set secure passwords and keys:
   ```
   MONGO_USERNAME=admin
   MONGO_PASSWORD=your_secure_password_here
   JWT_SECRET=your_jwt_secret_key_here
   API_KEY=your_shared_api_key_here
   NODE_ENV=production
   ```

### 4. Deploy with Docker Compose

1. While still in the docker directory, run:
   ```
   docker-compose up -d
   ```
2. This will build and start all services in detached mode
3. Check the status of your containers:
   ```
   docker-compose ps
   ```

### 5. Access the Application

Once deployed, you can access the Zynk components at:

- Admin Interface: `http://your-nas-ip:3000`
- Admin API: `http://your-nas-ip:4000/api`
- Content Connector: `http://your-nas-ip:5000/api/content`
- Content Connector Manifest: `http://your-nas-ip:5000/manifest.json`

### 6. Initial Setup

1. Access the Admin Interface at `http://your-nas-ip:3000`
2. Create an admin user account on first login
3. Configure templates and create items
4. Use the Sync page to synchronize data to the Content Connector

### 7. Templafy Integration

To integrate with Templafy:

1. In Templafy Admin Center, go to Integrations > Custom Content Connectors
2. Add a new connector with the URL: `http://your-nas-ip:5000/manifest.json`
3. Follow Templafy's documentation to complete the integration

## Maintenance

### Updating the Application

To update the application:

1. Pull the latest code
2. Navigate to the docker directory
3. Rebuild and restart the containers:
   ```
   docker-compose down
   docker-compose up -d --build
   ```

### Backing Up Data

The MongoDB data is stored in a Docker volume. To back it up:

1. Use Synology's built-in backup tools to back up the Docker volumes
2. Alternatively, you can export the MongoDB data:
   ```
   docker exec zynk-mongodb mongodump --out /data/db/backup
   ```

### Logs

To view logs for troubleshooting:

```
docker-compose logs -f [service-name]
```

Where `[service-name]` can be: mongodb, admin-backend, admin-frontend, or content-connector

## Troubleshooting

### Common Issues

1. **Cannot access the application**:
   - Check if all containers are running: `docker-compose ps`
   - Verify port forwarding settings on your router if accessing from outside your network

2. **Synchronization fails**:
   - Check the API key in the .env file
   - Verify network connectivity between containers

3. **MongoDB connection issues**:
   - Check MongoDB credentials in the .env file
   - Verify MongoDB container is running

For additional help, refer to the documentation or contact support.
