# Synology NAS Deployment Design

## Overview

This document outlines the design adaptations needed to deploy the Zynk project on a Synology NAS. The Zynk project consists of a custom content connector for Templafy and an admin interface, which will be containerized using Docker for deployment on Synology NAS devices.

## Synology NAS Requirements

### Hardware Requirements
- **NAS Model**: Any Synology NAS that supports Docker (most modern models)
- **CPU**: x86_64 architecture recommended for better performance
- **RAM**: Minimum 2GB, recommended 4GB or more
- **Storage**: At least 10GB free space for application and database

### Software Requirements
- **DSM Version**: 6.0 or later
- **Docker Package**: Installed from Synology Package Center
- **Docker Compose**: For managing multi-container applications

## Architecture Adaptations

The original architecture remains largely unchanged, but with specific adaptations for Synology NAS deployment:

1. **Containerization Strategy**
   - All components will be containerized using Docker
   - Docker Compose will be used for orchestration
   - Persistent volumes will be mapped to Synology storage

2. **Networking Considerations**
   - Internal Docker network for container communication
   - Port mapping for external access
   - Optional reverse proxy for SSL termination

3. **Resource Optimization**
   - Container resource limits to prevent overloading the NAS
   - Database optimization for lower resource usage
   - Caching strategies to reduce disk I/O

## Docker Compose Configuration

The application will be defined in a `docker-compose.yml` file with the following services:

### Frontend Container
```yaml
frontend:
  image: zynk-frontend
  build: ./admin_interface/frontend
  restart: unless-stopped
  depends_on:
    - backend
  ports:
    - "3000:3000"
  environment:
    - NEXT_PUBLIC_API_URL=http://backend:4000
  volumes:
    - frontend_node_modules:/app/node_modules
```

### Backend Container
```yaml
backend:
  image: zynk-backend
  build: ./admin_interface/backend
  restart: unless-stopped
  depends_on:
    - mongodb
  ports:
    - "4000:4000"
  environment:
    - MONGODB_URI=mongodb://mongodb:27017/zynk
    - JWT_SECRET=your_jwt_secret
    - TEMPLAFY_API_URL=https://api.templafy.com
  volumes:
    - backend_node_modules:/app/node_modules
    - ./uploads:/app/uploads
```

### Content Connector Container
```yaml
connector:
  image: zynk-connector
  build: ./content_connector
  restart: unless-stopped
  depends_on:
    - mongodb
  ports:
    - "5000:5000"
  environment:
    - MONGODB_URI=mongodb://mongodb:27017/zynk
    - JWT_SECRET=your_jwt_secret
  volumes:
    - connector_node_modules:/app/node_modules
    - ./uploads:/app/uploads
```

### MongoDB Container
```yaml
mongodb:
  image: mongo:5.0
  restart: unless-stopped
  ports:
    - "27017:27017"
  volumes:
    - mongodb_data:/data/db
  command: --wiredTigerCacheSizeGB 0.5
```

### Volumes
```yaml
volumes:
  mongodb_data:
  frontend_node_modules:
  backend_node_modules:
  connector_node_modules:
```

## Deployment Process

### Initial Setup
1. Install Docker package on Synology NAS
2. Enable SSH access to the NAS
3. Create a shared folder for the Zynk project
4. Copy project files to the shared folder

### Docker Setup
1. SSH into the Synology NAS
2. Navigate to the project directory
3. Build and start the containers:
   ```bash
   docker-compose up -d
   ```

### Configuration
1. Access the admin interface at `http://<nas-ip>:3000`
2. Configure Templafy API credentials
3. Set up the custom content connector in Templafy admin

## Network Configuration

### Internal Access
- Admin interface: `http://<nas-ip>:3000`
- Backend API: `http://<nas-ip>:4000`
- Content connector: `http://<nas-ip>:5000`

### External Access Options

#### Option 1: Direct Port Forwarding
1. Configure port forwarding on router to NAS IP
2. Forward ports 3000, 4000, and 5000 as needed
3. Access via `http://<public-ip>:<port>`

#### Option 2: Reverse Proxy with Synology's Nginx
1. Install Nginx package on Synology
2. Configure reverse proxy rules
3. Set up SSL certificates
4. Access via `https://<domain-name>`

#### Option 3: Docker-based Reverse Proxy
1. Add Traefik or Nginx Proxy Manager container
2. Configure domain routing
3. Set up automatic SSL with Let's Encrypt
4. Access via `https://<domain-name>`

## Performance Optimization

### Container Optimization
- Set memory limits for each container
- Configure CPU shares appropriately
- Use Alpine-based images where possible

### MongoDB Optimization
- Limit WiredTiger cache size
- Configure appropriate journal settings
- Set up regular database maintenance

### Application Optimization
- Implement efficient caching
- Optimize asset handling
- Minimize disk I/O operations

## Backup Strategy

### Database Backup
1. Set up automated MongoDB dumps
2. Store backups on a separate volume
3. Configure backup rotation policy

### Configuration Backup
1. Back up docker-compose.yml and environment files
2. Back up custom configurations
3. Document restoration procedures

## Monitoring and Maintenance

### Resource Monitoring
- Use Synology Resource Monitor
- Set up alerts for high resource usage
- Monitor container logs

### Update Process
1. Pull latest images
2. Back up current state
3. Update containers with minimal downtime

## Security Considerations

### Network Security
- Use internal Docker network
- Minimize exposed ports
- Implement proper firewall rules

### Application Security
- Secure JWT secrets
- Implement proper authentication
- Regular security updates

### Data Security
- Encrypt sensitive data
- Implement proper access controls
- Regular security audits

## Troubleshooting Guide

### Common Issues
- Container startup failures
- Database connection issues
- Network connectivity problems

### Diagnostic Steps
1. Check container logs
2. Verify network configurations
3. Test database connectivity
4. Validate environment variables

## Conclusion

With these adaptations, the Zynk project can be successfully deployed on a Synology NAS using Docker. The containerized approach ensures portability, easy updates, and efficient resource usage, making it well-suited for NAS deployment.
