# Custom Content Connector Requirements

## Overview
The custom content connector for Templafy allows users to leverage assets that live in a Digital Asset Management (DAM) system which Templafy does not already integrate with. For the Zynk project, we need to create a custom content connector that will be connected to our admin interface.

## Required Endpoints

Based on the Templafy documentation, the following endpoints must be implemented:

### 1. Authentication Endpoints

#### `/oauth/token`
This endpoint needs to return an access token which Templafy will use with each subsequent request.

**Request Parameters:**
- `grant_type`: Either "client_credentials" or "authorization_code" depending on the authorization method
- `client_id`: The client configured in the Templafy admin
- `client_secret`: The client secret configured in the Templafy admin (if configured)
- Additional parameters for authorization_code grant type

**Response Format:**
```json
{
    "access_token": "token_as_string",
    "token_type": "Bearer",
    "expires_in": 3600
}
```

#### `/oauth/authorize` (Only for Authorization Code flow)
This endpoint is only needed if using Authorization Code or Authorization code with PKCE.

**Request Parameters:**
- `response_type`: Will be "code"
- `client_id`: The client configured in the Templafy admin
- `state`: Templafy Tenant Id
- `scope`: The scopes configured in the Templafy admin
- `redirect_uri`: Will be "https://public.templafy.com/integrations/oauth/login-callback"
- Additional parameters for PKCE

**Response:** HTML page for user authentication, which should redirect to the redirect_uri with code and state parameters after successful authentication.

### 2. Content Endpoints

#### `/content`
This endpoint should serve the content and handle pagination & search.

**Request Parameters:**
- `skip`: The number of items to be skipped
- `limit`: The number of items to be returned
- `contentType`: The type of content to be returned (image, textElement, slide, slideElement, pdf, emailElement)
- `search`: (Optional) The keyword to be used to search the results
- `parentId`: (Optional) The id of the parent folder to be used to filter the results

**Request Headers:**
- `Authorization`: The access_token received from the `/oauth/token` endpoint formatted as "Bearer {access_token}"
- `x-TemplafyUser`: The email of the user who is logged in to Templafy

**Response Format:**
```json
{
    "content": [
        {
            "id": "1",
            "name": "Computer",
            "mimeType": "image/png",
            "previewUrl": "https://example.com/asset/1/preview",
            "tags": "computer,office,workplace",
            "altText": "Description of image"  // optional
        }
    ],
    "contentCount": 100,
    "offset": 30
}
```

#### `/content/{asset id}/download-url`
This endpoint should return the download url for a given asset id.

**Request Headers:**
- `Authorization`: The access_token received from the `/oauth/token` endpoint formatted as "Bearer {access_token}"
- `x-TemplafyUser`: The email of the user who is logged in to Templafy

**Response Format:**
```json
{
    "downloadUrl": "https://example.com/asset/1/download"
}
```

## Implementation Considerations

1. **Authentication**: We need to implement OAuth 2.0 authentication. For simplicity, we can start with the Client Credentials flow.

2. **Content Types**: The connector should support various content types, but for the initial implementation, we can focus on images as mentioned in the GitHub example.

3. **Deployment**: The connector cannot point to localhost due to security reasons. It needs to be deployed to a service that can be accessed by Templafy.

4. **Integration with Admin Interface**: The connector needs to be integrated with the admin interface, which will manage the items (name, description, and payload to Templafy's DocGen API).

5. **Case Sensitivity**: All property names, query/body parameters, and mime types are case sensitive.

## Technical Stack Considerations

1. **Language/Framework**: Based on the GitHub example, we can implement the connector using .NET 8, but we could also consider using Node.js for better integration with the admin interface.

2. **Hosting**: The connector needs to be hosted on a service that can be accessed by Templafy. We can use Docker for containerization.

3. **Storage**: We need a storage solution for the assets. For the initial implementation, we can use a simple file system storage.

4. **Security**: We need to implement proper authentication and authorization mechanisms.
