# Custom Content Connector Design

## Overview

The Custom Content Connector for the Zynk project enables Templafy users to access assets managed by the Zynk system. This document outlines the design of the Custom Content Connector, including its API endpoints, authentication mechanisms, and technical implementation.

## API Endpoints

### Authentication Endpoints

#### `/oauth/token`

**Purpose**: Return an access token for Templafy to use with subsequent requests.

**Method**: POST

**Request Parameters**:
- `grant_type`: Either "client_credentials" or "authorization_code"
- `client_id`: The client configured in Templafy admin
- `client_secret`: The client secret (if configured)
- Additional parameters for authorization_code flow

**Response**:
```json
{
    "access_token": "token_as_string",
    "token_type": "Bearer",
    "expires_in": 3600
}
```

#### `/oauth/authorize` (Optional)

**Purpose**: Provide authentication UI for Authorization Code flow.

**Method**: GET

**Request Parameters**:
- `response_type`: Will be "code"
- `client_id`: The client configured in Templafy admin
- `state`: Templafy Tenant Id
- `scope`: The scopes configured in Templafy admin
- `redirect_uri`: Templafy callback URL
- Additional parameters for PKCE

**Response**: HTML page for user authentication, which redirects to the redirect_uri with code and state parameters after successful authentication.

### Content Endpoints

#### `/content`

**Purpose**: Serve content with pagination and search capabilities.

**Method**: GET

**Request Parameters**:
- `skip`: Number of items to skip
- `limit`: Number of items to return
- `contentType`: Type of content (image, textElement, slide, slideElement, pdf, emailElement)
- `search`: (Optional) Search keyword
- `parentId`: (Optional) Parent folder ID

**Request Headers**:
- `Authorization`: Bearer token
- `x-TemplafyUser`: Email of logged-in Templafy user

**Response**:
```json
{
    "content": [
        {
            "id": "1",
            "name": "Asset Name",
            "mimeType": "image/png",
            "previewUrl": "https://example.com/asset/1/preview",
            "tags": "tag1,tag2,tag3",
            "altText": "Description of image"
        }
    ],
    "contentCount": 100,
    "offset": 30
}
```

#### `/content/{assetId}/download-url`

**Purpose**: Return download URL for a specific asset.

**Method**: GET

**Path Parameters**:
- `assetId`: ID of the asset

**Request Headers**:
- `Authorization`: Bearer token
- `x-TemplafyUser`: Email of logged-in Templafy user

**Response**:
```json
{
    "downloadUrl": "https://example.com/asset/1/download"
}
```

## Technical Implementation

### Technology Stack

- **Framework**: Node.js with Express
- **Database Access**: Mongoose ODM for MongoDB
- **Authentication**: OAuth 2.0 implementation
- **Storage**: File system with cloud storage option

### Component Structure

#### Authentication Module

- **Token Generation**: Create and validate JWT tokens
- **Client Validation**: Verify client credentials
- **User Authentication**: Handle user login for Authorization Code flow (if needed)

#### Content Management Module

- **Asset Retrieval**: Fetch assets from database
- **Pagination**: Handle skip and limit parameters
- **Filtering**: Filter by content type and parent folder
- **Search**: Search assets by keyword

#### Storage Module

- **File Storage**: Store and retrieve asset files
- **Preview Generation**: Create thumbnails for assets
- **URL Generation**: Create secure download URLs

### Database Integration

The Custom Content Connector will share the same database as the Admin Interface, using the following collections:

- **Assets**: Metadata about assets
- **Clients**: OAuth client credentials
- **Tokens**: Active access tokens

### Security Implementation

#### Authentication

- OAuth 2.0 Client Credentials flow (primary)
- Optional support for Authorization Code flow
- JWT-based access tokens with appropriate expiration

#### Authorization

- Validate access tokens for all content endpoints
- Check user permissions based on x-TemplafyUser header
- Implement rate limiting to prevent abuse

#### Secure URLs

- Generate time-limited signed URLs for asset downloads
- Validate request origin for asset access

## Integration with Admin Interface

The Custom Content Connector will integrate with the Admin Interface through:

1. **Shared Database**: Both components access the same MongoDB database
2. **Asset Management**: Assets created in the Admin Interface are available through the connector
3. **Configuration**: Connector settings managed through the Admin Interface

## Deployment Considerations

### Containerization

- Docker container for easy deployment
- Environment variables for configuration
- Health check endpoint for monitoring

### Scalability

- Stateless design for horizontal scaling
- Caching layer for frequently accessed assets
- Database connection pooling

### Monitoring

- Request logging for all endpoints
- Performance metrics collection
- Error tracking and reporting

## Error Handling

- Standardized error responses
- Detailed logging for troubleshooting
- Graceful degradation for partial system failures

## Implementation Plan

1. **Setup Project Structure**
   - Initialize Node.js project
   - Configure Express server
   - Set up MongoDB connection

2. **Implement Authentication**
   - Create OAuth token endpoint
   - Implement token validation middleware
   - Add optional authorization endpoint

3. **Implement Content Endpoints**
   - Create content listing endpoint with pagination
   - Add download URL generation endpoint
   - Implement filtering and search capabilities

4. **Add Security Features**
   - Implement JWT token generation and validation
   - Add rate limiting
   - Create secure URL generation

5. **Integration with Admin Interface**
   - Connect to shared database
   - Implement asset retrieval from Admin Interface storage
   - Add configuration management

6. **Testing and Optimization**
   - Unit tests for all components
   - Integration tests for API endpoints
   - Performance optimization

7. **Deployment Preparation**
   - Create Dockerfile
   - Set up environment variable configuration
   - Add health check and monitoring endpoints
