# DocGen API Requirements

## Overview
The DocGen API component of the Zynk project will be used to create non-editable, personalized fact sheets as PDFs for end-users through Templafy. The admin interface will allow administrators to create and manage items, each containing a name, description, and payload for Templafy's DocGen API.

## DocGen API Endpoints

Based on the Templafy documentation, the following are the key endpoints for document generation:

### Document Generation Endpoints

#### For Documents
```
POST https://{tenantId}.api.templafy.com/v2/libraries/{spaceId}/documents/assets/{assetId}/generate
```

#### For Presentations
```
POST https://{tenantId}.api.templafy.com/v2/libraries/{spaceId}/presentations/assets/{assetId}/generate
```

#### For Spreadsheets
```
POST https://{tenantId}.api.templafy.com/v2/libraries/{spaceId}/spreadsheets/assets/{assetId}/generate
```

#### For Text Elements
```
POST https://{tenantId}.api.templafy.com/v2/libraries/{spaceId}/text-elements/assets/{assetId}/generate
```

### Request Parameters

For all document generation endpoints:

**Request Body:**
```json
{
  "email": "user@example.com",  // Required: Email address to identify user in Templafy
  "data": {                     // Optional: Data to be used in file generation
    "field1": "value1",
    "field2": "value2"
  },
  "includePdf": true            // Optional: If true, response includes PDF download link
}
```

### Response Format

For all document generation endpoints:

```json
{
  "downloadUrl": "https://example.com/download/document.docx",  // Temporary access URL for generated file
  "fileSize": 12345,                                           // File size in bytes
  "checksum": "md5-hash",                                      // MD5 checksum of the bytes
  "mimeType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // Mime type
  "fileExtension": "docx",                                     // Suffix to the name of the file
  "pdfDownloadUrl": "https://example.com/download/document.pdf" // Only if includePdf was true
}
```

## Authentication

To use the DocGen API, an API token must be generated in the Templafy Admin Center:

1. Navigate to the account section
2. In the API Keys tab, click "Create key"
3. Provide a name for the key
4. Add the required scopes:
   - `library.generate`: to interact with the `/generate` endpoint
   - `library.read` or `library.readwrite` (optional): to retrieve folder or asset IDs

## Admin Interface Requirements

The admin interface for the Zynk project should allow administrators to:

1. **Create Items**: Add new items with:
   - Name: A descriptive name for the item
   - Description: Details about the item's purpose
   - Payload: The JSON payload to be sent to Templafy's DocGen API

2. **List Items**: View all existing items with their names and descriptions

3. **Edit Items**: Modify existing items' names, descriptions, and payloads

4. **Delete Items**: Remove items that are no longer needed

5. **Test Items**: Send a test request to the DocGen API with the item's payload

## Data Structure for Items

Each item in the admin interface should have the following structure:

```json
{
  "id": "unique-identifier",
  "name": "Item Name",
  "description": "Detailed description of the item",
  "payload": {
    "email": "user@example.com",
    "data": {
      "field1": "value1",
      "field2": "value2"
    },
    "includePdf": true
  },
  "templateInfo": {
    "spaceId": "space-identifier",
    "assetId": "asset-identifier",
    "documentType": "document" // One of: document, presentation, spreadsheet, text-element
  },
  "createdAt": "2025-04-17T15:29:00Z",
  "updatedAt": "2025-04-17T15:29:00Z"
}
```

## Implementation Considerations

1. **API Token Management**: The admin interface should securely store and manage the Templafy API token.

2. **Template Selection**: The admin interface should allow selection of templates from Templafy.

3. **Dynamic Data Fields**: The interface should provide a way to define and manage the data fields that will be used in the templates.

4. **PDF Generation**: Ensure that the `includePdf` parameter is set to true to generate non-editable PDF fact sheets.

5. **Error Handling**: Implement proper error handling for API requests and responses.

6. **Security**: Implement proper authentication and authorization for the admin interface.

7. **Logging**: Implement logging for all API requests and responses for debugging and auditing purposes.

## Technical Stack Considerations

1. **Frontend**: A modern web framework like React or Next.js for the admin interface.

2. **Backend**: A server-side technology that can handle API requests and responses, such as Node.js.

3. **Database**: A database to store the items, such as MongoDB or PostgreSQL.

4. **API Integration**: HTTP client libraries to interact with Templafy's DocGen API.

5. **Deployment**: Containerization with Docker for easy deployment.
